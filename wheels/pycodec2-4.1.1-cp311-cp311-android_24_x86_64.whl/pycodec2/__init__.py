# Pre-load libcodec2.so before importing the extension module
import os as _os
import ctypes as _ctypes

_this_dir = _os.path.dirname(_os.path.abspath(__file__))
_libcodec2_path = _os.path.join(_this_dir, 'libcodec2.so')

if _os.path.exists(_libcodec2_path):
    try:
        _ctypes.CDLL(_libcodec2_path, mode=_ctypes.RTLD_GLOBAL)
    except OSError as e:
        import sys
        print(f"Warning: Could not load libcodec2.so: {e}", file=sys.stderr)

from .pycodec2 import *
