"""
Pure Python wrapper for codec2 using ctypes.
This avoids symbol resolution issues with Cython extensions on Android.
"""
import ctypes
import os
import sys
import numpy as np

# Codec2 C mode constants (from codec2.h)
CODEC2_MODE_3200 = 0
CODEC2_MODE_2400 = 1
CODEC2_MODE_1600 = 2
CODEC2_MODE_1400 = 3
CODEC2_MODE_1300 = 4
CODEC2_MODE_1200 = 5
CODEC2_MODE_700C = 8
CODEC2_MODE_450 = 10
CODEC2_MODE_450PWB = 11

# Bitrate to C mode constant mapping (for pycodec2 API compatibility)
# pycodec2 accepts bitrate values like 700, 1200, etc. and maps them to C constants
_modes = {
    3200: CODEC2_MODE_3200,
    2400: CODEC2_MODE_2400,
    1600: CODEC2_MODE_1600,
    1400: CODEC2_MODE_1400,
    1300: CODEC2_MODE_1300,
    1200: CODEC2_MODE_1200,
    700: CODEC2_MODE_700C,
    450: CODEC2_MODE_450,
}

_libcodec2 = None

def _load_codec2():
    global _libcodec2
    if _libcodec2 is not None:
        return _libcodec2

    paths_to_try = []
    this_dir = os.path.dirname(os.path.abspath(__file__))
    paths_to_try.append(os.path.join(this_dir, 'libcodec2.so'))
    paths_to_try.append('libcodec2.so')

    for path in paths_to_try:
        try:
            _libcodec2 = ctypes.CDLL(path, mode=ctypes.RTLD_GLOBAL)
            break
        except OSError:
            continue

    if _libcodec2 is None:
        raise ImportError("Could not load libcodec2.so")

    _libcodec2.codec2_create.argtypes = [ctypes.c_int]
    _libcodec2.codec2_create.restype = ctypes.c_void_p
    _libcodec2.codec2_destroy.argtypes = [ctypes.c_void_p]
    _libcodec2.codec2_destroy.restype = None
    _libcodec2.codec2_samples_per_frame.argtypes = [ctypes.c_void_p]
    _libcodec2.codec2_samples_per_frame.restype = ctypes.c_int
    _libcodec2.codec2_bits_per_frame.argtypes = [ctypes.c_void_p]
    _libcodec2.codec2_bits_per_frame.restype = ctypes.c_int
    _libcodec2.codec2_bytes_per_frame.argtypes = [ctypes.c_void_p]
    _libcodec2.codec2_bytes_per_frame.restype = ctypes.c_int
    _libcodec2.codec2_encode.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ubyte), ctypes.POINTER(ctypes.c_short)]
    _libcodec2.codec2_encode.restype = None
    _libcodec2.codec2_decode.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_short), ctypes.POINTER(ctypes.c_ubyte)]
    _libcodec2.codec2_decode.restype = None

    return _libcodec2

class Codec2:
    """Codec2 audio codec wrapper compatible with pycodec2 API."""
    def __init__(self, mode):
        """
        Create a Codec2 instance.
        
        Args:
            mode: Bitrate value (700, 1200, 1300, 1400, 1600, 2400, 3200) or
                  C mode constant (CODEC2_MODE_*)
        """
        lib = _load_codec2()
        
        # Map bitrate to C mode constant if needed
        if mode in _modes:
            c_mode = _modes[mode]
        else:
            c_mode = mode  # Assume it's already a C mode constant
        
        self._c2 = lib.codec2_create(c_mode)
        if not self._c2:
            raise RuntimeError(f"Failed to create Codec2 instance with mode {mode}")
        self._mode = mode
        self._c_mode = c_mode
        self._lib = lib

    def __del__(self):
        if hasattr(self, '_c2') and self._c2 and hasattr(self, '_lib') and self._lib:
            self._lib.codec2_destroy(self._c2)
            self._c2 = None

    def samples_per_frame(self):
        return self._lib.codec2_samples_per_frame(self._c2)

    def bits_per_frame(self):
        return self._lib.codec2_bits_per_frame(self._c2)

    def bytes_per_frame(self):
        return self._lib.codec2_bytes_per_frame(self._c2)

    def encode(self, speech):
        speech = np.asarray(speech, dtype=np.int16)
        speech_ptr = speech.ctypes.data_as(ctypes.POINTER(ctypes.c_short))
        nbytes = self.bytes_per_frame()
        bits = (ctypes.c_ubyte * nbytes)()
        self._lib.codec2_encode(self._c2, bits, speech_ptr)
        return bytes(bits)

    def decode(self, bits):
        bits_array = (ctypes.c_ubyte * len(bits))(*bits)
        nsamples = self.samples_per_frame()
        speech = (ctypes.c_short * nsamples)()
        self._lib.codec2_decode(self._c2, speech, bits_array)
        return np.array(speech, dtype=np.int16)
